/* ============================================================
   DRS.VIP - Main JavaScript
   راشد نجيب سنان الحداد · درع الإسلام
   ============================================================ */

/* ===== Background Canvas - Particles Network ===== */
const canvas = document.getElementById('bg-canvas');
if (canvas) {
    const ctx = canvas.getContext('2d');
    let particles = [];
    const mouse = { x: null, y: null, radius: 150 };

    function resizeCanvas() {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    }
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    window.addEventListener('mousemove', (e) => {
        mouse.x = e.clientX;
        mouse.y = e.clientY;
    });

    const colors = ['#00f0ff', '#ffffff', '#a855f7', '#ff2a6d'];

    class Particle {
        constructor() {
            this.x = Math.random() * canvas.width;
            this.y = Math.random() * canvas.height;
            this.size = Math.random() * 2.5 + 0.5;
            this.baseSize = this.size;
            this.speedX = (Math.random() - 0.5) * 0.5;
            this.speedY = (Math.random() - 0.5) * 0.5;
            this.color = colors[Math.floor(Math.random() * colors.length)];
            this.opacity = Math.random() * 0.6 + 0.2;
            this.opacityDir = Math.random() > 0.5 ? 1 : -1;
            this.opacitySpeed = Math.random() * 0.005 + 0.002;
        }
        update() {
            this.x += this.speedX; this.y += this.speedY;
            if (this.x < 0) this.x = canvas.width;
            if (this.x > canvas.width) this.x = 0;
            if (this.y < 0) this.y = canvas.height;
            if (this.y > canvas.height) this.y = 0;
            if (mouse.x !== null) {
                const dx = mouse.x - this.x, dy = mouse.y - this.y;
                const d = Math.sqrt(dx * dx + dy * dy);
                if (d < mouse.radius) {
                    const force = (mouse.radius - d) / mouse.radius;
                    this.x -= (dx / d) * force * 2;
                    this.y -= (dy / d) * force * 2;
                    this.size = this.baseSize + force * 2;
                } else { this.size = this.baseSize; }
            }
            this.opacity += this.opacityDir * this.opacitySpeed;
            if (this.opacity >= 0.8) this.opacityDir = -1;
            if (this.opacity <= 0.15) this.opacityDir = 1;
        }
        draw() {
            ctx.beginPath();
            ctx.arc(this.x, this.y, Math.max(0.1, this.size), 0, Math.PI * 2);
            ctx.fillStyle = this.color;
            ctx.globalAlpha = this.opacity;
            ctx.shadowBlur = 15;
            ctx.shadowColor = this.color;
            ctx.fill();
            ctx.shadowBlur = 0;
            ctx.globalAlpha = 1;
        }
    }

    function initParticles() {
        particles = [];
        const count = Math.min(70, Math.floor(window.innerWidth / 18));
        for (let i = 0; i < count; i++) particles.push(new Particle());
    }
    initParticles();

    function connectParticles() {
        const maxD = 130;
        for (let a = 0; a < particles.length; a++) {
            for (let b = a + 1; b < particles.length; b++) {
                const dx = particles[a].x - particles[b].x;
                const dy = particles[a].y - particles[b].y;
                const d = Math.sqrt(dx * dx + dy * dy);
                if (d < maxD) {
                    const op = (1 - d / maxD) * 0.3;
                    ctx.beginPath();
                    ctx.strokeStyle = `rgba(0, 240, 255, ${op})`;
                    ctx.lineWidth = 0.6;
                    ctx.moveTo(particles[a].x, particles[a].y);
                    ctx.lineTo(particles[b].x, particles[b].y);
                    ctx.stroke();
                }
            }
        }
    }

    function animateParticles() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        particles.forEach(p => { p.update(); p.draw(); });
        connectParticles();
        requestAnimationFrame(animateParticles);
    }
    animateParticles();
}

/* ===== Scroll Progress + Active Nav ===== */
const scrollProgress = document.querySelector('.scroll-progress');
const topNavLinks = document.querySelectorAll('.top-nav a');
const sections = document.querySelectorAll('section[id]');

window.addEventListener('scroll', () => {
    const scrollTop = window.scrollY;
    const docHeight = document.documentElement.scrollHeight - window.innerHeight;
    if (scrollProgress) scrollProgress.style.width = (scrollTop / docHeight * 100) + '%';

    let current = '';
    sections.forEach(section => {
        if (scrollTop >= section.offsetTop - 120) current = section.id;
    });
    topNavLinks.forEach(link => {
        link.classList.toggle('active', link.getAttribute('href') === '#' + current);
    });
});

/* ===== Typing Animation ===== */
const typedTextEl = document.getElementById('typedText');
if (typedTextEl) {
    const phrases = [
        'باحث في الأمن السيبراني الدفاعي',
        'مؤسس أكاديمية راشد التقنية',
        'مطوّر مشاريع DRS.VIP و Astra',
        'مهندس حلول الأتمتة والذكاء الاصطناعي المحلي',
        'صاحب نمط DRS للشعر'
    ];
    let phraseIndex = 0, charIndex = 0, isDeleting = false;
    function typeEffect() {
        const cur = phrases[phraseIndex];
        if (isDeleting) { typedTextEl.textContent = cur.substring(0, charIndex - 1); charIndex--; }
        else { typedTextEl.textContent = cur.substring(0, charIndex + 1); charIndex++; }
        let speed = isDeleting ? 50 : 100;
        if (!isDeleting && charIndex === cur.length) { speed = 2000; isDeleting = true; }
        else if (isDeleting && charIndex === 0) { isDeleting = false; phraseIndex = (phraseIndex + 1) % phrases.length; speed = 500; }
        setTimeout(typeEffect, speed);
    }
    typeEffect();
}

/* ===== Reveal on Scroll ===== */
const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('active');
            // Animate skill bars
            if (entry.target.classList.contains('skill-card')) {
                const bar = entry.target.querySelector('.skill-card__progress');
                if (bar && !bar.dataset.animated) {
                    bar.style.width = bar.dataset.width + '%';
                    bar.dataset.animated = 'true';
                }
            }
        }
    });
}, { threshold: 0.15 });
document.querySelectorAll('.reveal').forEach(el => revealObserver.observe(el));

/* ===== Hero Counters ===== */
let countersDone = false;
function animateCounters() {
    if (countersDone) return;
    countersDone = true;
    document.querySelectorAll('.hero__stat-num').forEach(counter => {
        const target = parseInt(counter.dataset.count);
        const dur = 2000, start = performance.now();
        function update(now) {
            const p = Math.min((now - start) / dur, 1);
            const eased = p === 1 ? 1 : 1 - Math.pow(2, -10 * p);
            counter.textContent = Math.floor(eased * target) + (target >= 100 ? '+' : '');
            if (p < 1) requestAnimationFrame(update);
            else counter.textContent = target + (target >= 100 ? '+' : '');
        }
        requestAnimationFrame(update);
    });
}
const heroSection = document.getElementById('hero');
if (heroSection) {
    const heroObs = new IntersectionObserver((entries) => {
        entries.forEach(e => { if (e.isIntersecting) { animateCounters(); heroObs.unobserve(e.target); } });
    }, { threshold: 0.3 });
    heroObs.observe(heroSection);
}

/* ===== Skills Tabs ===== */
const skillTabs = document.querySelectorAll('.skills__tab');
const skillGrids = document.querySelectorAll('.skills__grid');
skillTabs.forEach(tab => {
    tab.addEventListener('click', () => {
        const target = tab.dataset.tab;
        skillTabs.forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        skillGrids.forEach(grid => {
            grid.classList.toggle('active', grid.dataset.grid === target);
            if (grid.dataset.grid === target) {
                grid.querySelectorAll('.skill-card__progress').forEach(bar => {
                    bar.style.width = '0'; bar.dataset.animated = '';
                    setTimeout(() => {
                        bar.style.width = bar.dataset.width + '%';
                        bar.dataset.animated = 'true';
                    }, 50);
                });
            }
        });
    });
});

/* ===== Projects Filter ===== */
const projectFilters = document.querySelectorAll('.projects__filter');
const projectCards = document.querySelectorAll('.project-card');
projectFilters.forEach(filter => {
    filter.addEventListener('click', () => {
        const cat = filter.dataset.filter;
        projectFilters.forEach(f => f.classList.remove('active'));
        filter.classList.add('active');
        projectCards.forEach(card => {
            const matches = cat === 'all' || card.dataset.category === cat;
            if (matches) {
                card.style.display = 'block';
                setTimeout(() => { card.style.opacity = '1'; card.style.transform = 'translateY(0) scale(1)'; }, 50);
            } else {
                card.style.opacity = '0'; card.style.transform = 'translateY(20px) scale(0.95)';
                setTimeout(() => { card.style.display = 'none'; }, 300);
            }
        });
    });
});
projectCards.forEach(c => c.style.transition = 'all 0.4s');

/* ===== Testimonials Slider ===== */
const slider = document.getElementById('testimonialsSlider');
if (slider) {
    const testimonials = document.querySelectorAll('.testimonial');
    const dotsContainer = document.getElementById('testimonialsDots');
    const prevBtn = document.getElementById('prevTestimonial');
    const nextBtn = document.getElementById('nextTestimonial');
    let current = 0, autoInt;

    testimonials.forEach((_, i) => {
        const dot = document.createElement('div');
        dot.className = 'testimonials__dot' + (i === 0 ? ' active' : '');
        dot.addEventListener('click', () => goTo(i));
        dotsContainer.appendChild(dot);
    });
    function goTo(idx) {
        current = (idx + testimonials.length) % testimonials.length;
        slider.style.transform = `translateX(${current * 100}%)`;
        document.querySelectorAll('.testimonials__dot').forEach((d, i) => d.classList.toggle('active', i === current));
        resetAuto();
    }
    function next() { goTo(current + 1); }
    function prev() { goTo(current - 1); }
    if (nextBtn) nextBtn.addEventListener('click', next);
    if (prevBtn) prevBtn.addEventListener('click', prev);
    function resetAuto() { clearInterval(autoInt); autoInt = setInterval(next, 6000); }
    resetAuto();
    slider.parentElement.addEventListener('mouseenter', () => clearInterval(autoInt));
    slider.parentElement.addEventListener('mouseleave', resetAuto);
}

/* ===== Toast Notifications ===== */
function showToast(type, title, message) {
    const container = document.getElementById('toastContainer');
    if (!container) return;
    const icons = { success: 'fa-circle-check', error: 'fa-circle-xmark', warning: 'fa-triangle-exclamation', info: 'fa-circle-info' };
    const toast = document.createElement('div');
    toast.className = `toast toast--${type}`;
    toast.innerHTML = `<i class="fa-solid ${icons[type]} toast__icon"></i><div class="toast__content"><div class="toast__title">${title}</div><div class="toast__msg">${message}</div></div>`;
    container.appendChild(toast);
    setTimeout(() => toast.remove(), 3100);
}

/* ===== Contact Form ===== */
const contactForm = document.getElementById('contactForm');
if (contactForm) {
    contactForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const data = {
            name: document.getElementById('name').value,
            email: document.getElementById('email').value,
            subject: document.getElementById('subject').value,
            message: document.getElementById('message').value
        };

        // Clear previous errors
        document.querySelectorAll('.form-error').forEach(el => el.classList.remove('show'));

        const submitBtn = contactForm.querySelector('button[type="submit"]');
        const original = submitBtn.innerHTML;
        submitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> جاري الإرسال...';
        submitBtn.disabled = true;

        try {
            const res = await fetch('/api/contact', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });
            const result = await res.json();

            if (result.success) {
                showToast('success', 'تم الإرسال بنجاح!', result.message);
                contactForm.reset();
            } else if (result.errors) {
                Object.keys(result.errors).forEach(field => {
                    const errEl = document.getElementById(field + 'Error');
                    if (errEl) errEl.classList.add('show');
                });
                showToast('error', 'خطأ في النموذج', 'يرجى تصحيح الحقول المطلوبة');
            }
        } catch (err) {
            showToast('error', 'خطأ', 'تعذر الاتصال بالخادم');
        }
        submitBtn.innerHTML = original;
        submitBtn.disabled = false;
    });
}

/* ===== Floating Side Menu (بدلاً من الشريط السفلي) ===== */
const floatingMenu = document.getElementById('floatingMenu');
const floatingMenuFab = document.getElementById('floatingMenuFab');
if (floatingMenuFab) {
    floatingMenuFab.addEventListener('click', (e) => {
        e.stopPropagation();
        floatingMenu.classList.toggle('open');
    });
    document.addEventListener('click', (e) => {
        if (!floatingMenu.contains(e.target)) floatingMenu.classList.remove('open');
    });
}

/* ===== AI Chatbot ===== */
const chatbotToggle = document.getElementById('chatbotToggle');
const chatbotWindow = document.getElementById('chatbotWindow');
const chatbotClose = document.getElementById('chatbotClose');
const chatbotMessages = document.getElementById('chatbotMessages');
const chatbotForm = document.getElementById('chatbotForm');
const chatbotInput = document.getElementById('chatbotInput');

if (chatbotToggle) {
    let isOpen = false;
    let hasGreeted = false;

    function toggleChatbot() {
        isOpen = !isOpen;
        chatbotWindow.classList.toggle('open', isOpen);
        chatbotToggle.querySelector('i').className = isOpen ? 'fa-solid fa-xmark' : 'fa-solid fa-robot';
        if (isOpen && !hasGreeted) {
            hasGreeted = true;
            setTimeout(() => addBotMessage(WELCOME_MSG), 300);
        }
    }
    chatbotToggle.addEventListener('click', toggleChatbot);
    chatbotClose.addEventListener('click', toggleChatbot);

    const WELCOME_MSG = 'مرحباً بك! 👋 أنا "درع" المساعد الذكي لـ DRS.VIP. كيف يمكنني مساعدتك؟ يمكنني الإجابة عن:\n• مشاريع راشد التقنية\n• الأمن السيبراني الدفاعي\n• الذكاء الاصطناعي المحلي\n• طرق التواصل';

    function addBotMessage(text) {
        const msg = document.createElement('div');
        msg.className = 'chatbot__msg chatbot__msg--bot';
        msg.textContent = text;
        chatbotMessages.appendChild(msg);
        chatbotMessages.scrollTop = chatbotMessages.scrollHeight;
    }
    function addUserMessage(text) {
        const msg = document.createElement('div');
        msg.className = 'chatbot__msg chatbot__msg--user';
        msg.textContent = text;
        chatbotMessages.appendChild(msg);
        chatbotMessages.scrollTop = chatbotMessages.scrollHeight;
    }
    function showTyping() {
        const msg = document.createElement('div');
        msg.className = 'chatbot__msg chatbot__msg--bot chatbot__msg--typing';
        msg.id = 'typingIndicator';
        msg.innerHTML = '<span></span><span></span><span></span>';
        chatbotMessages.appendChild(msg);
        chatbotMessages.scrollTop = chatbotMessages.scrollHeight;
    }
    function hideTyping() {
        const t = document.getElementById('typingIndicator');
        if (t) t.remove();
    }

    chatbotForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const text = chatbotInput.value.trim();
        if (!text) return;
        addUserMessage(text);
        chatbotInput.value = '';
        showTyping();
        try {
            const res = await fetch('/api/chat', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ message: text, sessionId: 'web-' + Date.now() })
            });
            const data = await res.json();
            hideTyping();
            if (data.success) {
                setTimeout(() => addBotMessage(data.response), 200);
            } else {
                addBotMessage('عذراً، حدث خطأ. حاول مرة أخرى.');
            }
        } catch (err) {
            hideTyping();
            addBotMessage('تعذر الاتصال بالخادم. تأكد من اتصالك بالإنترنت.');
        }
    });

    // Quick reply buttons
    document.querySelectorAll('.chatbot__quick-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            chatbotInput.value = btn.textContent;
            chatbotForm.dispatchEvent(new Event('submit'));
        });
    });
}

/* ===== Welcome Toast ===== */
setTimeout(() => {
    showToast('info', 'مرحباً بك في DRS.VIP!', 'أنا درع الإسلام · راشد الحداد. استعرض مشاريعي أو تحدث مع المساعد الذكي');
}, 1500);

/* ===== Smooth Scroll for anchor links ===== */
document.querySelectorAll('a[href^="#"]').forEach(link => {
    link.addEventListener('click', (e) => {
        const href = link.getAttribute('href');
        if (href === '#' || href.length < 2) return;
        const target = document.querySelector(href);
        if (target) {
            e.preventDefault();
            window.scrollTo({ top: target.offsetTop - 90, behavior: 'smooth' });
        }
    });
});

console.log('%c DRS.VIP ', 'background: linear-gradient(135deg, #00f0ff, #a855f7); color: black; font-size: 20px; font-weight: bold; padding: 10px 20px; border-radius: 8px;');
console.log('%c درع الإسلام · راشد نجيب سنان الحداد ', 'color: #00f0ff; font-size: 14px;');
