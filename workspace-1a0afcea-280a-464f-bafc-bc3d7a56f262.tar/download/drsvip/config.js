/**
 * DRS.VIP - Website Configuration
 * راشد نجيب سنان الحداد · درع الإسلام
 */
const path = require('path');

module.exports = {
    // App
    appName: 'DRS.VIP',
    author: 'راشد نجيب سنان الحداد',
    alias: 'درع الإسلام',
    age: 22,
    country: 'اليمن',
    url: 'https://drs.xo.je',
    github: 'https://github.com/drs-vip-1',
    whatsapp: 'https://wa.me/966553405949',
    telegram: 'https://t.me/Chat_DRSVIP',

    // Server
    port: process.env.PORT || 3000,
    host: process.env.HOST || '0.0.0.0',

    // Paths
    root: __dirname,
    publicDir: path.join(__dirname, 'public'),
    viewsDir: path.join(__dirname, 'views'),
    dataDir: path.join(__dirname, 'data'),
    uploadsDir: path.join(__dirname, 'public', 'uploads'),

    // Admin
    adminUsername: 'admin',
    // Default password: drsvip2024 (change after first login)
    adminPasswordHash: '$2a$10$8KzQVZmF2vNqYJ5xQ5wR7eLJZQyq1X8vK9Hk2K5R8jLZ7vNqYJ5xK',

    // Session
    sessionSecret: 'drsvip-secret-key-2024-change-in-production',

    // AI Chatbot (uses built-in knowledge base + simulated responses)
    aiEnabled: true,
    aiName: 'درع · المساعد الذكي',
    aiWelcomeMessage: 'مرحباً بك! أنا المساعد الذكي لـ DRS.VIP. كيف يمكنني مساعدتك اليوم؟'
};
