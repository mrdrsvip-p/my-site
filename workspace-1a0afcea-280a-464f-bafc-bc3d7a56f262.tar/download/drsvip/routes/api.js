/**
 * API routes (chatbot, contact AJAX, etc.)
 */
const express = require('express');
const router = express.Router();
const db = require('../lib/db');
const chatbot = require('../lib/chatbot');
const config = require('../config');

// ===== AI Chatbot endpoint =====
router.post('/chat', (req, res) => {
    const { message, sessionId } = req.body;
    if (!message || !message.trim()) {
        return res.json({ success: false, error: 'الرسالة فارغة' });
    }

    const result = chatbot.chat(message.trim(), sessionId || req.sessionID);
    res.json({
        success: true,
        response: result.response,
        timestamp: result.timestamp,
        botName: result.botName
    });
});

// ===== Contact form (AJAX) =====
router.post('/contact', (req, res) => {
    const { name, email, subject, message } = req.body;
    const errors = {};

    if (!name || name.trim().length < 2) errors.name = 'يرجى إدخال الاسم';
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) errors.email = 'بريد إلكتروني غير صحيح';
    if (!subject || subject.trim().length < 3) errors.subject = 'يرجى إدخال الموضوع';
    if (!message || message.trim().length < 10) errors.message = 'الرسالة قصيرة جداً';

    if (Object.keys(errors).length > 0) {
        return res.json({ success: false, errors });
    }

    db.insert('messages', {
        name: name.trim(),
        email: email.trim(),
        subject: subject.trim(),
        message: message.trim(),
        read: false
    });

    res.json({ success: true, message: 'تم استلام رسالتك بنجاح! سأرد عليك في أقرب وقت ممكن.' });
});

// ===== Get site stats (public) =====
router.get('/stats', (req, res) => {
    const settings = db.getSettings();
    res.json({
        projects: db.all('projects').length,
        blogPosts: db.all('blog').length,
        skills: db.all('skills').length,
        testimonials: db.all('testimonials').length,
        stats: settings.stats
    });
});

module.exports = router;
