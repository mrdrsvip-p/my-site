/**
 * Admin panel routes - authentication required
 */
const express = require('express');
const router = express.Router();
const session = require('express-session');
const bcrypt = require('bcryptjs');
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const db = require('../lib/db');
const config = require('../config');

// Auth middleware
const authRequired = (req, res, next) => {
    if (!req.session.admin) {
        return res.redirect('/admin/login');
    }
    next();
};

// ===== Login Page =====
router.get('/login', (req, res) => {
    if (req.session.admin) return res.redirect('/admin');
    res.render('admin/login', { title: 'تسجيل الدخول · لوحة التحكم', error: null });
});

// ===== Login Handler =====
router.post('/login', (req, res) => {
    const { username, password } = req.body;
    const authFile = path.join(config.dataDir, 'auth.json');

    try {
        const auth = JSON.parse(fs.readFileSync(authFile, 'utf8'));
        if (username === auth.username && bcrypt.compareSync(password, auth.passwordHash)) {
            req.session.admin = { username, loginAt: new Date().toISOString() };
            return res.redirect('/admin');
        }
    } catch (e) {
        console.error('Auth error:', e.message);
    }
    res.render('admin/login', { title: 'تسجيل الدخول', error: 'اسم المستخدم أو كلمة المرور غير صحيحة' });
});

// ===== Logout =====
router.get('/logout', (req, res) => {
    req.session.destroy();
    res.redirect('/admin/login');
});

// ===== Dashboard =====
router.get('/', authRequired, (req, res) => {
    const messages = db.all('messages').sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).slice(0, 5);
    const chatLogs = db.getChatLogs(20);
    const stats = {
        projects: db.all('projects').length,
        blogPosts: db.all('blog').length,
        skills: db.all('skills').length,
        messages: db.all('messages').length,
        unreadMessages: db.all('messages').filter(m => !m.read).length,
        testimonials: db.all('testimonials').length,
        chatCount: db.getChatLogs(9999).length
    };
    res.render('admin/dashboard', {
        title: 'لوحة التحكم · ' + config.appName,
        active: 'dashboard',
        stats, messages, chatLogs
    });
});

// ===== Projects Management =====
router.get('/projects', authRequired, (req, res) => {
    const projects = db.all('projects').sort((a, b) => a.order - b.order);
    res.render('admin/projects', { title: 'المشاريع · لوحة التحكم', active: 'projects', projects });
});

router.post('/projects/add', authRequired, (req, res) => {
    const { title, category, icon, short, description, tags, role, order, featured } = req.body;
    db.insert('projects', {
        title, category, icon: icon || 'fa-code', short, description,
        tags: tags ? tags.split(',').map(t => t.trim()) : [],
        role, order: parseInt(order) || 0,
        featured: featured === 'on'
    });
    res.redirect('/admin/projects');
});

router.post('/projects/:id/update', authRequired, (req, res) => {
    const { title, category, icon, short, description, tags, role, order, featured } = req.body;
    db.update('projects', req.params.id, {
        title, category, icon, short, description,
        tags: tags ? tags.split(',').map(t => t.trim()) : [],
        role, order: parseInt(order) || 0,
        featured: featured === 'on'
    });
    res.redirect('/admin/projects');
});

router.post('/projects/:id/delete', authRequired, (req, res) => {
    db.remove('projects', req.params.id);
    res.redirect('/admin/projects');
});

// ===== Blog Management =====
router.get('/blog', authRequired, (req, res) => {
    const posts = db.all('blog').sort((a, b) => new Date(b.date) - new Date(a.date));
    res.render('admin/blog', { title: 'المدونة · لوحة التحكم', active: 'blog', posts });
});

router.post('/blog/add', authRequired, (req, res) => {
    const { title, excerpt, content, category, image, date, readTime, featured } = req.body;
    db.insert('blog', {
        title, excerpt, content, category, image: image || 'default',
        date: date || new Date().toISOString().split('T')[0],
        readTime: parseInt(readTime) || 5,
        featured: featured === 'on'
    });
    res.redirect('/admin/blog');
});

router.post('/blog/:id/update', authRequired, (req, res) => {
    const { title, excerpt, content, category, image, date, readTime, featured } = req.body;
    db.update('blog', req.params.id, {
        title, excerpt, content, category, image, date,
        readTime: parseInt(readTime) || 5,
        featured: featured === 'on'
    });
    res.redirect('/admin/blog');
});

router.post('/blog/:id/delete', authRequired, (req, res) => {
    db.remove('blog', req.params.id);
    res.redirect('/admin/blog');
});

// ===== Skills Management =====
router.get('/skills', authRequired, (req, res) => {
    const skills = db.all('skills');
    res.render('admin/skills', { title: 'المهارات · لوحة التحكم', active: 'skills', skills });
});

router.post('/skills/add', authRequired, (req, res) => {
    const { category, name, level, icon, note } = req.body;
    db.insert('skills', {
        category, name, level: parseInt(level) || 50,
        icon: icon || 'fa-code', note
    });
    res.redirect('/admin/skills');
});

router.post('/skills/:id/update', authRequired, (req, res) => {
    const { category, name, level, icon, note } = req.body;
    db.update('skills', req.params.id, {
        category, name, level: parseInt(level) || 50, icon, note
    });
    res.redirect('/admin/skills');
});

router.post('/skills/:id/delete', authRequired, (req, res) => {
    db.remove('skills', req.params.id);
    res.redirect('/admin/skills');
});

// ===== Experience Management =====
router.get('/experience', authRequired, (req, res) => {
    const experience = db.all('experience').sort((a, b) => a.order - b.order);
    res.render('admin/experience', { title: 'الخبرات · لوحة التحكم', active: 'experience', experience });
});

router.post('/experience/add', authRequired, (req, res) => {
    const { date, role, company, description, achievements, order } = req.body;
    db.insert('experience', {
        date, role, company, description,
        achievements: achievements ? achievements.split('\n').filter(a => a.trim()) : [],
        order: parseInt(order) || 0
    });
    res.redirect('/admin/experience');
});

router.post('/experience/:id/update', authRequired, (req, res) => {
    const { date, role, company, description, achievements, order } = req.body;
    db.update('experience', req.params.id, {
        date, role, company, description,
        achievements: achievements ? achievements.split('\n').filter(a => a.trim()) : [],
        order: parseInt(order) || 0
    });
    res.redirect('/admin/experience');
});

router.post('/experience/:id/delete', authRequired, (req, res) => {
    db.remove('experience', req.params.id);
    res.redirect('/admin/experience');
});

// ===== Testimonials Management =====
router.get('/testimonials', authRequired, (req, res) => {
    const testimonials = db.all('testimonials');
    res.render('admin/testimonials', { title: 'الشهادات · لوحة التحكم', active: 'testimonials', testimonials });
});

router.post('/testimonials/add', authRequired, (req, res) => {
    const { name, role, avatar, rating, text } = req.body;
    db.insert('testimonials', {
        name, role, avatar: avatar || 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&h=120&fit=crop',
        rating: parseFloat(rating) || 5, text
    });
    res.redirect('/admin/testimonials');
});

router.post('/testimonials/:id/update', authRequired, (req, res) => {
    const { name, role, avatar, rating, text } = req.body;
    db.update('testimonials', req.params.id, {
        name, role, avatar, rating: parseFloat(rating) || 5, text
    });
    res.redirect('/admin/testimonials');
});

router.post('/testimonials/:id/delete', authRequired, (req, res) => {
    db.remove('testimonials', req.params.id);
    res.redirect('/admin/testimonials');
});

// ===== Messages =====
router.get('/messages', authRequired, (req, res) => {
    const messages = db.all('messages').sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    res.render('admin/messages', { title: 'الرسائل · لوحة التحكم', active: 'messages', messages });
});

router.post('/messages/:id/read', authRequired, (req, res) => {
    db.update('messages', req.params.id, { read: true });
    res.redirect('/admin/messages');
});

router.post('/messages/:id/delete', authRequired, (req, res) => {
    db.remove('messages', req.params.id);
    res.redirect('/admin/messages');
});

// ===== Chat Logs =====
router.get('/chatlogs', authRequired, (req, res) => {
    const logs = db.getChatLogs(500).reverse();
    res.render('admin/chatlogs', { title: 'محادثات البوت · لوحة التحكم', active: 'chatlogs', logs });
});

router.post('/chatlogs/clear', authRequired, (req, res) => {
    fs.writeFileSync(path.join(config.dataDir, 'chatlogs.json'), '[]');
    res.redirect('/admin/chatlogs');
});

// ===== Settings =====
router.get('/settings', authRequired, (req, res) => {
    const settings = db.getSettings();
    res.render('admin/settings', { title: 'الإعدادات · لوحة التحكم', active: 'settings', settings, saved: false });
});

router.post('/settings', authRequired, (req, res) => {
    const s = db.getSettings();
    const updated = { ...s, ...req.body };
    if (req.body.stats) {
        try { updated.stats = JSON.parse(req.body.stats); } catch (e) {}
    } else {
        updated.stats = {
            projects: parseInt(req.body.statsProjects) || 0,
            tools: parseInt(req.body.statsTools) || 0,
            versions: parseInt(req.body.statsVersions) || 0,
            academies: parseInt(req.body.statsAcademies) || 0
        };
    }
    if (req.body.available) updated.available = req.body.available === 'on';
    db.saveSettings(updated);
    res.render('admin/settings', { title: 'الإعدادات · لوحة التحكم', active: 'settings', settings: updated, saved: true });
});

// ===== Change Password =====
router.post('/password', authRequired, (req, res) => {
    const { current, newpass, confirm } = req.body;
    const authFile = path.join(config.dataDir, 'auth.json');
    const auth = JSON.parse(fs.readFileSync(authFile, 'utf8'));

    if (!bcrypt.compareSync(current, auth.passwordHash)) {
        return res.render('admin/settings', { title: 'الإعدادات', active: 'settings', settings: db.getSettings(), saved: false, error: 'كلمة المرور الحالية غير صحيحة' });
    }
    if (newpass !== confirm || newpass.length < 6) {
        return res.render('admin/settings', { title: 'الإعدادات', active: 'settings', settings: db.getSettings(), saved: false, error: 'كلمة المرور الجديدة غير متطابقة أو قصيرة جداً (6 أحرف минимум)' });
    }

    auth.passwordHash = bcrypt.hashSync(newpass, 10);
    fs.writeFileSync(authFile, JSON.stringify(auth, null, 2));
    res.render('admin/settings', { title: 'الإعدادات', active: 'settings', settings: db.getSettings(), saved: true, successMsg: 'تم تغيير كلمة المرور بنجاح' });
});

module.exports = router;
