/**
 * Main site routes
 */
const express = require('express');
const router = express.Router();
const db = require('../lib/db');
const config = require('../config');

// ===== Home =====
router.get('/', (req, res) => {
    const settings = db.getSettings();
    const projects = db.all('projects').filter(p => p.featured).sort((a, b) => a.order - b.order).slice(0, 6);
    const skills = db.all('skills');
    const experience = db.all('experience').sort((a, b) => a.order - b.order);
    const testimonials = db.all('testimonials');
    const blog = db.all('blog').slice(0, 3);

    res.render('index', {
        title: `${config.alias} · ${config.appName}`,
        settings,
        projects,
        skills,
        experience,
        testimonials,
        blog,
        isHome: true
    });
});

// ===== About Page =====
router.get('/about', (req, res) => {
    const settings = db.getSettings();
    const skills = db.all('skills');
    const experience = db.all('experience').sort((a, b) => a.order - b.order);
    res.render('about', {
        title: 'التعريف · ' + config.appName,
        settings, skills, experience
    });
});

// ===== Projects Page =====
router.get('/projects', (req, res) => {
    const settings = db.getSettings();
    const projects = db.all('projects').sort((a, b) => a.order - b.order);
    res.render('projects', {
        title: 'المشاريع · ' + config.appName,
        settings, projects
    });
});

// ===== Single Project =====
router.get('/projects/:id', (req, res) => {
    const project = db.findById('projects', req.params.id);
    if (!project) return res.status(404).render('404', { title: '404' });
    res.render('project-detail', {
        title: project.title + ' · ' + config.appName,
        project,
        settings: db.getSettings()
    });
});

// ===== Blog Page =====
router.get('/blog', (req, res) => {
    const settings = db.getSettings();
    const posts = db.all('blog').sort((a, b) => new Date(b.date) - new Date(a.date));
    res.render('blog', {
        title: 'المدونة · ' + config.appName,
        settings, posts
    });
});

// ===== Single Blog Post =====
router.get('/blog/:id', (req, res) => {
    const post = db.findById('blog', req.params.id);
    if (!post) return res.status(404).render('404', { title: '404' });
    const related = db.all('blog').filter(p => p.id !== post.id && p.category === post.category).slice(0, 2);
    res.render('blog-detail', {
        title: post.title + ' · ' + config.appName,
        post, related,
        settings: db.getSettings()
    });
});

// ===== Contact Page =====
router.get('/contact', (req, res) => {
    const settings = db.getSettings();
    res.render('contact', { title: 'التواصل · ' + config.appName, settings });
});

// ===== Handle contact form =====
router.post('/contact', (req, res) => {
    const { name, email, subject, message } = req.body;
    if (!name || !email || !subject || !message) {
        return res.json({ success: false, error: 'جميع الحقول مطلوبة' });
    }
    db.insert('messages', { name, email, subject, message, read: false });
    res.json({ success: true, message: 'تم استلام رسالتك بنجاح! سأرد عليك قريباً.' });
});

module.exports = router;
