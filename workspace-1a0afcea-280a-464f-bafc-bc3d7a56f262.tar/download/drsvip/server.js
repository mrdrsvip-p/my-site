/**
 * DRS.VIP - Main Server (Express)
 * راشد نجيب سنان الحداد · درع الإسلام
 */
const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const path = require('path');
const fs = require('fs');
const config = require('./config');
const db = require('./lib/db');

const app = express();

// ===== View Engine =====
app.set('view engine', 'ejs');
app.set('views', config.viewsDir);

// ===== Middleware =====
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static(config.publicDir));

// Session
app.use(session({
    secret: config.sessionSecret,
    resave: false,
    saveUninitialized: false,
    cookie: { maxAge: 24 * 60 * 60 * 1000 } // 24 hours
}));

// Inject global data into all views
app.use((req, res, next) => {
    res.locals.config = config;
    res.locals.settings = db.getSettings();
    res.locals.path = req.path;
    res.locals.isAdmin = !!req.session.admin;
    res.locals.currentYear = new Date().getFullYear();
    next();
});

// ===== Routes =====
const mainRoutes = require('./routes/main');
const apiRoutes = require('./routes/api');
const adminRoutes = require('./routes/admin');

app.use('/', mainRoutes);
app.use('/api', apiRoutes);
app.use('/admin', adminRoutes);

// 404
app.use((req, res) => {
    res.status(404).render('404', { title: '404 - الصفحة غير موجودة' });
});

// Error handler
app.use((err, req, res, next) => {
    console.error('Server error:', err);
    res.status(500).render('error', { title: 'خطأ في الخادم', error: err.message });
});

// ===== Start =====
const PORT = config.port;
app.listen(PORT, config.host, () => {
    console.log('═══════════════════════════════════════════════');
    console.log(`  🛡️  DRS.VIP Server Running`);
    console.log(`  👤 درع الإسلام · راشد الحداد`);
    console.log('═══════════════════════════════════════════════');
    console.log(`  📍 Local:    http://localhost:${PORT}`);
    console.log(`  📍 Network:  http://0.0.0.0:${PORT}`);
    console.log(`  🔐 Admin:    http://localhost:${PORT}/admin`);
    console.log(`     User: admin | Pass: drsvip2024`);
    console.log('═══════════════════════════════════════════════');
});

module.exports = app;
