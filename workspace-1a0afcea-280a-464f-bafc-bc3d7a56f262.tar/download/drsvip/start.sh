#!/bin/bash
# DRS.VIP - Server Start Script
# راشد نجيب سنان الحداد · درع الإسلام

cd "$(dirname "$0")"

echo "═══════════════════════════════════════════════"
echo "  🛡️  DRS.VIP - Website Server"
echo "  👤 درع الإسلام · راشد الحداد"
echo "═══════════════════════════════════════════════"

# Check if node_modules exists
if [ ! -d "node_modules" ]; then
    echo "📦 Installing dependencies..."
    npm install
fi

# Check if data is seeded
if [ ! -f "data/projects.json" ]; then
    echo "🌱 First run - seeding database..."
    node lib/seed.js
fi

echo "🚀 Starting server..."
node server.js
