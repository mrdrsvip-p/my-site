# راشد نجيب سنان الحداد · درع الإسلام · DRS.VIP

موقع شخصي احترافي متكامل لمطوّر برمجيات وباحث في الأمن السيبراني الدفاعي، بتصميم **Glass Morphism + Cyberpunk + Futuristic** باستخدام HTML/CSS/JavaScript فقط.

## الهوية

| الحقل | القيمة |
|-------|--------|
| الاسم الكامل | راشد نجيب سنان الحداد |
| اللقب الرقمي | درع الإسلام |
| الشعار الرسمي | DRS.VIP |
| المسمى | مطور برمجيات وباحث في الأمن السيبراني |
| التوجه | الأمن السيبراني الدفاعي والتعليمي البحت |
| الموقع الرسمي | https://drs.xo.je |
| GitHub | https://github.com/drs-vip-1 |
| واتساب | +966 55 340 5949 |
| تليجرام | @Chat_DRSVIP |

## المشاريع الرئيسية المعروضة في الموقع

1. **أكاديمية راشد التقنية** - المؤسس والمدرب الرئيسي
2. **جناح الأمن السيبراني DRS.VIP** - محاكاة أمن الأجهزة واختبار الثغرات دفاعياً
3. **مشروع Astra** - أنظمة الحماية وبيئات الأمان
4. **سلسلة DRS-AUTO v8.0 ULTIMATE** - أتمتة منصات التواصل الاجتماعي
5. **لوحة مفاتيح Keyboard DRS.VIP** - لوحة مفاتيح أندرويد بموسوعة برمجية
6. **منصة القرشي للتجارة** - منصة Full-Stack متكاملة
7. **إطار Odysseus** - ذكاء اصطناعي تنفيذي محلي بالكامل
8. **استضافة وتعديل نماذج LLM** - Llama / DeepSeek / Qwen عبر Ollama و Open WebUI

## أقسام الموقع

1. **Hero** - عنوان متدرّج + شعار DRS.VIP + تأثير الكتابة + الصورة الشخصية + إحصائيات
2. **About (التعريف)** - السيرة الكاملة + نمط DRS للشعر + معلومات أساسية + روابط رسمية
3. **Skills** - 4 تصنيفات: برمجة / أمن سيبراني / ذكاء اصطناعي / أدوات ومنصات
4. **Projects** - 8 مشاريع حقيقية مع فلترة (الكل / أمن سيبراني / أتمتة / ذكاء اصطناعي / منصات)
5. **Experience** - 5 محطات قيادية (الأكاديمية / DRS-AUTO / Odysseus / DRS.VIP+Astra / Keyboard+القرشي)
6. **Testimonials** - 4 شهادات من متدربين ومتعاونين
7. **Blog** - 3 مقالات (الأمن الدفاعي / Local LLM / أتمتة Python)
8. **Contact** - روابط رسمية (واتساب، تليجرام، الموقع، GitHub) + نموذج + خريطة

## المميزات التقنية

### التصميم
- **Glass Morphism** + **Dark Mode** بألوان نيون: سماوي `#00f0ff`، وردي `#ff2a6d`، بنفسجي `#a855f7`
- **خطوط**: Plus Jakarta Sans + IBM Plex Sans Arabic + Fira Code
- **Border Radius**: 35px للبطاقات، 25px للأزرار

### التأثيرات التفاعلية
- خلفية Canvas متحركة بـ 70 جزيء + Network Effect + تفاعل مع الماوس
- مؤشر مخصص (نقطة + دائرة) مع Ripple عند النقر
- شريط جانبي 80px يتوسع إلى 250px عند التحويم
- Typing Animation للعناوين الفرعية (5 عبارات)
- Reveal on Scroll باستخدام Intersection Observer
- Parallax للأشكال العائمة

### الميزات المتقدمة
- ✅ Toast Notifications
- ✅ Form Validation كامل
- ✅ Clipboard API لنسخ معلومات التواصل
- ✅ Counter Animation للإحصائيات
- ✅ Scroll Progress Bar
- ✅ Active Nav Indicator
- ✅ Keyboard Shortcut `Ctrl/Cmd + K`
- ✅ SEO: Meta tags + JSON-LD structured data
- ✅ Accessibility: ARIA labels + Keyboard navigation
- ✅ Responsive كامل مع Bottom Navigation للموبايل

## التقنيات المستخدمة

| التقنية | الاستخدام |
|---------|-----------|
| HTML5 Semantic | بنية الصفحة |
| CSS3 | متغيرات + Grid + Flexbox + Animations |
| Vanilla JavaScript | بدون أي مكتبات |
| Canvas API | خلفية الجزيئات المتحركة |
| Intersection Observer | تأثيرات الظهور عند التمرير |
| Font Awesome 6.4.0 | الأيقونات (CDN) |
| Google Fonts | الخطوط الثلاثة |

## كيفية التشغيل

### الطريقة 1: فتح مباشر
انقر مرتين على `index.html` لفتحه في المتصفح.

### الطريقة 2: خادم محلي (موصى به)
```bash
python3 -m http.server 8000
# ثم افتح: http://localhost:8000
```

## بنية الملف

```
download/
├── index.html      # الموقع الكامل (HTML + CSS + JS في ملف واحد)
├── profile.jpg     # الصورة الشخصية للمطور
└── README.md       # هذا الملف
```

## التخصيص

### تغيير الألوان
عدّل المتغيرات في `:root` داخل وسم `<style>`:
```css
:root {
    --accent-cyan: #00f0ff;
    --accent-pink: #ff2a6d;
    --accent-purple: #a855f7;
}
```

### تغيير المحتوى
- **المعلومات الشخصية**: في قسم About و Hero
- **الصورة**: استبدل `profile.jpg` بصورتك
- **المشاريع**: عدّل بطاقات `<article class="project-card">`
- **روابط التواصل**: كلها تشير إلى الروابط الرسمية لـ DRS.VIP

---

**© 2024 راشد نجيب سنان الحداد · درع الإسلام · DRS.VIP — في خدمة الفضاء السيبراني الآمن**
